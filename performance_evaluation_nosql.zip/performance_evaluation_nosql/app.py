"""
app.py
Flask web application — entry point for the performance evaluation dashboard.

Routes:
  GET  /              → Home / landing page
  GET  /benchmark     → Benchmark control panel
  POST /benchmark/run → Start benchmark (streaming SSE progress)
  GET  /results       → Raw results table
  GET  /analytics     → Charts & analytical insights
  GET  /api/results   → JSON: raw results
  GET  /api/analysis  → JSON: full analysis
"""

import json
import os
import threading

from flask import Flask, render_template, request, jsonify, Response, stream_with_context

from dataset_generator   import SIZES as DATASET_SIZES
from performance_analyzer import get_full_analysis, get_summary_table, get_chart_data

app = Flask(__name__)
app.config["SECRET_KEY"] = "nosql-benchmark-2024"

# ── Shared benchmark state ─────────────────────────────────────────────
_bench_lock    = threading.Lock()
_bench_running = False
_bench_progress = {"pct": 0, "msg": "Idle"}
_bench_error    = None


def _do_benchmark(size_labels: list):
    global _bench_running, _bench_progress, _bench_error
    from benchmark_engine import run_benchmarks

    def cb(pct, msg):
        _bench_progress["pct"] = pct
        _bench_progress["msg"] = msg

    try:
        _bench_error = None
        run_benchmarks(size_labels=size_labels, progress_callback=cb)
    except Exception as e:
        _bench_error = str(e)
        _bench_progress["msg"] = f"Error: {e}"
    finally:
        _bench_running = False
        _bench_progress["pct"] = 100


# ── Routes ─────────────────────────────────────────────────────────────

@app.route("/")
def index():
    has_results = os.path.exists(
        os.path.join(os.path.dirname(__file__), "results", "results.csv")
    )
    return render_template("index.html", has_results=has_results)


@app.route("/benchmark")
def benchmark():
    global _bench_running
    return render_template(
        "benchmark.html",
        sizes=list(DATASET_SIZES.keys()),
        running=_bench_running,
        progress=_bench_progress,
    )


@app.route("/benchmark/run", methods=["POST"])
def benchmark_run():
    global _bench_running, _bench_progress
    with _bench_lock:
        if _bench_running:
            return jsonify({"status": "already_running"}), 409
        sizes = request.json.get("sizes", list(DATASET_SIZES.keys()))
        _bench_running = True
        _bench_progress = {"pct": 0, "msg": "Starting benchmark…"}
        t = threading.Thread(target=_do_benchmark, args=(sizes,), daemon=True)
        t.start()
    return jsonify({"status": "started"})


@app.route("/benchmark/status")
def benchmark_status():
    return jsonify({
        "running":  _bench_running,
        "progress": _bench_progress,
        "error":    _bench_error,
    })


@app.route("/results")
def results():
    rows = get_summary_table()
    return render_template("results.html", rows=rows, count=len(rows))


@app.route("/analytics")
def analytics():
    analysis = get_full_analysis()
    chart_json = json.dumps(analysis.get("chart_data", {}))
    return render_template(
        "analytics.html",
        rankings=analysis.get("rankings", {}),
        insights=analysis.get("insights", []),
        chart_json=chart_json,
    )


# ── JSON API ───────────────────────────────────────────────────────────

@app.route("/api/results")
def api_results():
    return jsonify(get_summary_table())


@app.route("/api/analysis")
def api_analysis():
    return jsonify(get_full_analysis())


# ── Main ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
