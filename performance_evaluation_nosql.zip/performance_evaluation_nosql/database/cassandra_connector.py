"""
database/cassandra_connector.py
Apache Cassandra CRUD connector for the benchmark engine.
"""

import time
import uuid
from typing import List, Dict, Any

try:
    from cassandra.cluster import Cluster
    from cassandra.auth import PlainTextAuthProvider
    from cassandra import ConsistencyLevel
    from cassandra.query import BatchStatement, SimpleStatement
    CASSANDRA_AVAILABLE = True
except ImportError:
    CASSANDRA_AVAILABLE = False

KEYSPACE   = "nosql_benchmark"
TABLE_NAME = "users"

CREATE_KEYSPACE_CQL = f"""
CREATE KEYSPACE IF NOT EXISTS {KEYSPACE}
WITH replication = {{'class': 'SimpleStrategy', 'replication_factor': '1'}};
"""

CREATE_TABLE_CQL = f"""
CREATE TABLE IF NOT EXISTS {KEYSPACE}.{TABLE_NAME} (
    user_id  TEXT PRIMARY KEY,
    name     TEXT,
    email    TEXT,
    city     TEXT,
    age      INT,
    ts       TEXT
);
"""

BATCH_SIZE = 200   # Cassandra recommends small batches


class CassandraConnector:
    def __init__(self, contact_points: List[str] = None, port: int = 9042):
        self.contact_points = contact_points or ["127.0.0.1"]
        self.port      = port
        self.cluster   = None
        self.session   = None
        self.available = CASSANDRA_AVAILABLE

    # ------------------------------------------------------------------
    def connect(self) -> bool:
        if not self.available:
            return False
        try:
            self.cluster = Cluster(
                contact_points=self.contact_points,
                port=self.port,
                connect_timeout=5,
            )
            self.session = self.cluster.connect()
            self.session.execute(CREATE_KEYSPACE_CQL)
            self.session.set_keyspace(KEYSPACE)
            self.session.execute(CREATE_TABLE_CQL)
            return True
        except Exception:
            self.available = False
            return False

    def disconnect(self):
        if self.cluster:
            self.cluster.shutdown()

    # ------------------------------------------------------------------
    def _truncate(self):
        self.session.execute(f"TRUNCATE {TABLE_NAME}")

    def insert(self, records: List[Dict[str, Any]]) -> float:
        if not self.available:
            return -1.0
        self._truncate()
        insert_stmt = self.session.prepare(
            f"INSERT INTO {TABLE_NAME} (user_id, name, email, city, age, ts) "
            "VALUES (?, ?, ?, ?, ?, ?)"
        )
        start = time.perf_counter()
        for i in range(0, len(records), BATCH_SIZE):
            batch = BatchStatement(consistency_level=ConsistencyLevel.ONE)
            for rec in records[i: i + BATCH_SIZE]:
                batch.add(insert_stmt, (
                    rec["user_id"], rec["name"], rec["email"],
                    rec["city"], int(rec["age"]), rec["timestamp"]
                ))
            self.session.execute(batch)
        return time.perf_counter() - start

    def read(self, limit: int = 0) -> float:
        if not self.available:
            return -1.0
        cql = f"SELECT * FROM {TABLE_NAME}"
        if limit:
            cql += f" LIMIT {limit}"
        stmt = SimpleStatement(cql, fetch_size=1000)
        start = time.perf_counter()
        _ = list(self.session.execute(stmt))
        return time.perf_counter() - start

    def update(self, records: List[Dict[str, Any]]) -> float:
        if not self.available:
            return -1.0
        upd = self.session.prepare(
            f"UPDATE {TABLE_NAME} SET age = ? WHERE user_id = ?"
        )
        start = time.perf_counter()
        for i in range(0, len(records), BATCH_SIZE):
            batch = BatchStatement(consistency_level=ConsistencyLevel.ONE)
            for rec in records[i: i + BATCH_SIZE]:
                batch.add(upd, (int(rec["age"]) + 1, rec["user_id"]))
            self.session.execute(batch)
        return time.perf_counter() - start

    def delete(self, user_ids: List[str]) -> float:
        if not self.available:
            return -1.0
        dlt = self.session.prepare(
            f"DELETE FROM {TABLE_NAME} WHERE user_id = ?"
        )
        start = time.perf_counter()
        for i in range(0, len(user_ids), BATCH_SIZE):
            batch = BatchStatement(consistency_level=ConsistencyLevel.ONE)
            for uid in user_ids[i: i + BATCH_SIZE]:
                batch.add(dlt, (uid,))
            self.session.execute(batch)
        return time.perf_counter() - start

    def count(self) -> int:
        if not self.available:
            return 0
        row = self.session.execute(f"SELECT COUNT(*) FROM {TABLE_NAME}").one()
        return row[0] if row else 0
