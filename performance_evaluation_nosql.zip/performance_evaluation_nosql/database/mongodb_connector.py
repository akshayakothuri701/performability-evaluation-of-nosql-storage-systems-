"""
database/mongodb_connector.py
MongoDB CRUD connector for the benchmark engine.
"""

import time
from typing import List, Dict, Any

try:
    from pymongo import MongoClient, ASCENDING
    from pymongo.errors import ConnectionFailure, BulkWriteError
    MONGO_AVAILABLE = True
except ImportError:
    MONGO_AVAILABLE = False


DB_NAME   = "nosql_benchmark"
COLL_NAME = "users"


class MongoDBConnector:
    def __init__(self, host: str = "localhost", port: int = 27017):
        self.host = host
        self.port = port
        self.client = None
        self.db     = None
        self.collection = None
        self.available  = MONGO_AVAILABLE

    # ------------------------------------------------------------------
    def connect(self) -> bool:
        if not self.available:
            return False
        try:
            self.client = MongoClient(
                self.host, self.port,
                serverSelectionTimeoutMS=3000
            )
            self.client.admin.command("ping")
            self.db         = self.client[DB_NAME]
            self.collection = self.db[COLL_NAME]
            self.collection.create_index([("user_id", ASCENDING)], unique=True)
            return True
        except (ConnectionFailure, Exception):
            self.available = False
            return False

    def disconnect(self):
        if self.client:
            self.client.close()

    # ------------------------------------------------------------------
    def insert(self, records: List[Dict[str, Any]]) -> float:
        """Insert records; return elapsed seconds."""
        if not self.available:
            return -1.0
        self.collection.delete_many({})          # clean slate
        docs = [dict(r) for r in records]
        start = time.perf_counter()
        try:
            self.collection.insert_many(docs, ordered=False)
        except BulkWriteError:
            pass
        return time.perf_counter() - start

    def read(self, limit: int = 0) -> float:
        """Full collection scan; return elapsed seconds."""
        if not self.available:
            return -1.0
        start = time.perf_counter()
        cursor = self.collection.find({})
        if limit:
            cursor = cursor.limit(limit)
        _ = list(cursor)
        return time.perf_counter() - start

    def update(self, records: List[Dict[str, Any]]) -> float:
        """Update age field for every record; return elapsed seconds."""
        if not self.available:
            return -1.0
        start = time.perf_counter()
        for rec in records:
            self.collection.update_one(
                {"user_id": rec["user_id"]},
                {"$set": {"age": int(rec["age"]) + 1}}
            )
        return time.perf_counter() - start

    def delete(self, user_ids: List[str]) -> float:
        """Delete records by user_id list; return elapsed seconds."""
        if not self.available:
            return -1.0
        start = time.perf_counter()
        self.collection.delete_many({"user_id": {"$in": user_ids}})
        return time.perf_counter() - start

    def count(self) -> int:
        if not self.available:
            return 0
        return self.collection.count_documents({})
