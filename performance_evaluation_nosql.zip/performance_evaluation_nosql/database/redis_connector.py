"""
database/redis_connector.py
Redis CRUD connector for the benchmark engine.
Stores each user as a Redis Hash: key = "user:{user_id}"
"""

import time
import json
from typing import List, Dict, Any

try:
    import redis as redis_lib
    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False

PIPELINE_BATCH = 500   # flush pipeline every N ops


class RedisConnector:
    def __init__(self, host: str = "localhost", port: int = 6379, db: int = 0):
        self.host  = host
        self.port  = port
        self.db    = db
        self.r     = None
        self.available = REDIS_AVAILABLE

    # ------------------------------------------------------------------
    def connect(self) -> bool:
        if not self.available:
            return False
        try:
            self.r = redis_lib.Redis(
                host=self.host, port=self.port, db=self.db,
                socket_connect_timeout=3, decode_responses=True
            )
            self.r.ping()
            return True
        except Exception:
            self.available = False
            return False

    def disconnect(self):
        if self.r:
            self.r.close()

    # ------------------------------------------------------------------
    def _flush_users(self):
        """Delete all user:* keys."""
        keys = self.r.keys("user:*")
        if keys:
            self.r.delete(*keys)

    def insert(self, records: List[Dict[str, Any]]) -> float:
        if not self.available:
            return -1.0
        self._flush_users()
        start = time.perf_counter()
        pipe = self.r.pipeline(transaction=False)
        for i, rec in enumerate(records):
            pipe.hset(f"user:{rec['user_id']}", mapping={
                "name":      rec["name"],
                "email":     rec["email"],
                "city":      rec["city"],
                "age":       str(rec["age"]),
                "timestamp": rec["timestamp"],
            })
            if (i + 1) % PIPELINE_BATCH == 0:
                pipe.execute()
                pipe = self.r.pipeline(transaction=False)
        pipe.execute()
        return time.perf_counter() - start

    def read(self, limit: int = 0) -> float:
        if not self.available:
            return -1.0
        keys = self.r.keys("user:*")
        if limit:
            keys = keys[:limit]
        start = time.perf_counter()
        pipe = self.r.pipeline(transaction=False)
        for key in keys:
            pipe.hgetall(key)
        _ = pipe.execute()
        return time.perf_counter() - start

    def update(self, records: List[Dict[str, Any]]) -> float:
        if not self.available:
            return -1.0
        start = time.perf_counter()
        pipe = self.r.pipeline(transaction=False)
        for i, rec in enumerate(records):
            pipe.hset(f"user:{rec['user_id']}", "age", str(int(rec["age"]) + 1))
            if (i + 1) % PIPELINE_BATCH == 0:
                pipe.execute()
                pipe = self.r.pipeline(transaction=False)
        pipe.execute()
        return time.perf_counter() - start

    def delete(self, user_ids: List[str]) -> float:
        if not self.available:
            return -1.0
        keys = [f"user:{uid}" for uid in user_ids]
        start = time.perf_counter()
        for i in range(0, len(keys), PIPELINE_BATCH):
            self.r.delete(*keys[i: i + PIPELINE_BATCH])
        return time.perf_counter() - start

    def count(self) -> int:
        if not self.available:
            return 0
        return len(self.r.keys("user:*"))
