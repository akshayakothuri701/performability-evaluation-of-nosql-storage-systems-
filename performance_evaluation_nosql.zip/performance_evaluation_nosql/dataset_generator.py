"""
dataset_generator.py
Generates synthetic datasets of varying sizes for benchmarking.
Saves CSV files to the datasets/ directory.
"""

import os
import pandas as pd
from faker import Faker
import numpy as np
from datetime import datetime

fake = Faker()

DATASET_DIR = os.path.join(os.path.dirname(__file__), "datasets")
os.makedirs(DATASET_DIR, exist_ok=True)

SIZES = {
    "1k":   1_000,
    "10k":  10_000,
    "50k":  50_000,
    "100k": 100_000,
}

CITIES = [
    "Mumbai", "Delhi", "Bangalore", "Hyderabad", "Chennai",
    "Pune", "Kolkata", "Ahmedabad", "Jaipur", "Lucknow",
    "New York", "London", "Tokyo", "Paris", "Sydney",
]


def generate_dataset(size: int) -> pd.DataFrame:
    """Generate a DataFrame with `size` synthetic user records."""
    np.random.seed(42)
    data = {
        "user_id":   [f"U{str(i).zfill(8)}" for i in range(1, size + 1)],
        "name":      [fake.name() for _ in range(size)],
        "email":     [fake.email() for _ in range(size)],
        "city":      np.random.choice(CITIES, size=size).tolist(),
        "age":       np.random.randint(18, 70, size=size).tolist(),
        "timestamp": [
            datetime.fromtimestamp(
                fake.unix_time(start_datetime="-5y")
            ).strftime("%Y-%m-%d %H:%M:%S")
            for _ in range(size)
        ],
    }
    return pd.DataFrame(data)


def generate_all_datasets() -> dict:
    """Generate and save all dataset sizes. Returns paths dict."""
    paths = {}
    for label, size in SIZES.items():
        path = os.path.join(DATASET_DIR, f"dataset_{label}.csv")
        if os.path.exists(path):
            print(f"[SKIP]  dataset_{label}.csv already exists.")
        else:
            print(f"[GEN]   Generating {size:,} records → dataset_{label}.csv …", end=" ")
            df = generate_dataset(size)
            df.to_csv(path, index=False)
            print("done.")
        paths[label] = path
    return paths


def load_dataset(label: str) -> pd.DataFrame:
    """Load a dataset CSV by label (e.g. '1k', '10k')."""
    path = os.path.join(DATASET_DIR, f"dataset_{label}.csv")
    if not os.path.exists(path):
        print(f"[INFO]  dataset_{label}.csv not found, generating …")
        generate_all_datasets()
    return pd.read_csv(path)


if __name__ == "__main__":
    generate_all_datasets()
    print("\nAll datasets ready in:", DATASET_DIR)
