# Deployment Guide — Windows

## Prerequisites
- Windows 10 / 11
- Internet connection

---

## Step 1 — Install Python 3.11+

1. Go to https://www.python.org/downloads/
2. Download **Python 3.11** (or later) Windows installer.
3. Run the installer → tick **"Add Python to PATH"** → click **Install Now**.
4. Verify:
   ```
   python --version
   ```

---

## Step 2 — Clone / Extract the Project

Place the `performance_evaluation_nosql/` folder anywhere, e.g.:
```
C:\Projects\performance_evaluation_nosql\
```

---

## Step 3 — Create a Virtual Environment

Open **Command Prompt** and navigate to the project folder:
```
cd C:\Projects\performance_evaluation_nosql
python -m venv venv
venv\Scripts\activate
```

---

## Step 4 — Install Python Dependencies

```
pip install -r requirements.txt
```

---

## Step 5 — Install MongoDB (optional — project works without it)

1. Download MongoDB Community Server from https://www.mongodb.com/try/download/community
2. Run the installer with default settings (installs as a Windows Service).
3. MongoDB will start automatically on port **27017**.
4. Verify: open MongoDB Compass or run `mongosh`.

---

## Step 6 — Install Apache Cassandra (optional)

1. Install **Java 11** (OpenJDK): https://adoptium.net/
2. Download Cassandra 4.x from https://cassandra.apache.org/download/
3. Extract to `C:\cassandra\`
4. Open Command Prompt as Administrator:
   ```
   C:\cassandra\bin\cassandra.bat -f
   ```
5. Cassandra runs on port **9042** by default.

---

## Step 7 — Install Redis (optional)

1. Download the Windows port from https://github.com/tporadowski/redis/releases
2. Run the installer (or extract the ZIP).
3. Start Redis:
   ```
   redis-server
   ```
4. Redis runs on port **6379** by default.

> **Note:** If none of the databases are installed, the project automatically falls back to simulation mode and still generates realistic benchmark data for the dashboard.

---

## Step 8 — Run the Flask Application

With the virtual environment active:
```
python app.py
```

You should see:
```
 * Running on http://0.0.0.0:5000
```

Open a browser and go to: **http://localhost:5000**

---

## Step 9 — Run Your First Benchmark

1. Navigate to **Benchmark** in the top menu.
2. Select the dataset sizes you want to test (start with **1k** and **10k** for a quick run).
3. Click **Run Benchmark**.
4. Watch the live progress log.
5. When complete, click **View Analytics** to see charts and insights.

---

## Quick-Start Command Summary

```bat
cd C:\Projects\performance_evaluation_nosql
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Then open: http://localhost:5000

---

## Troubleshooting

| Problem | Solution |
|---------|---------|
| `ModuleNotFoundError: flask` | Make sure the virtual env is activated: `venv\Scripts\activate` |
| `ConnectionRefusedError` for MongoDB | Start MongoDB service: `net start MongoDB` |
| Cassandra times out | It can take 30–60 s to start; wait and retry |
| Redis not found | Start `redis-server.exe` from the Redis folder |
| Port 5000 in use | Edit `app.py` last line: `app.run(port=5001)` |
| `pip` SSL error behind a proxy | `pip install --trusted-host pypi.org --trusted-host files.pythonhosted.org -r requirements.txt` |
