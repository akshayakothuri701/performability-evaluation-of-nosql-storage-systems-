# Performance Evaluation of NoSQL Storage Systems
### Complete Project Documentation — B.Tech / MCA Final Year Project

---

## Abstract

This project presents a comprehensive benchmarking framework for evaluating and comparing the performance of three widely-used NoSQL database management systems: MongoDB, Apache Cassandra, and Redis. The system generates synthetic datasets of configurable sizes (1 K–100 K records), executes standardised CRUD workloads, and captures execution time, throughput (records/second), CPU utilisation, and memory consumption for each operation. A Flask-powered web dashboard visualises the results through interactive Chart.js charts and automated analytical insights, enabling data-driven selection of the most appropriate NoSQL technology for a given workload pattern.

---

## 1. Introduction

The proliferation of web-scale applications has driven the adoption of NoSQL ("Not Only SQL") databases that sacrifice rigid schemas and ACID guarantees in exchange for horizontal scalability, flexible data models, and sub-millisecond latency. However, the NoSQL landscape is fragmented: document stores (MongoDB), wide-column stores (Cassandra), and in-memory key-value stores (Redis) each exhibit dramatically different performance profiles depending on access patterns and data size.

Developers and architects must choose among these systems with limited empirical guidance tailored to their specific workload. This project fills that gap by providing a reproducible, automated benchmark suite and a rich visual analysis layer.

---

## 2. Problem Statement

- No single NoSQL database excels across all workload types.
- Performance differences between databases can span orders of magnitude depending on operation type and dataset size.
- Existing benchmarking tools (YCSB, TPC-x) require complex setup and do not provide an integrated web-based visualisation layer.
- Organisations lack a lightweight, self-hosted tool that simultaneously benchmarks multiple databases and generates human-readable analytical summaries.

---

## 3. Objectives

1. Design and implement a synthetic dataset generator producing realistic user records at multiple scales.
2. Build modular database connectors for MongoDB, Cassandra, and Redis that expose a uniform CRUD interface.
3. Develop a benchmark engine that orchestrates CRUD workloads and captures time, throughput, CPU, and memory metrics.
4. Implement a performance analyser that identifies best-in-class databases across multiple dimensions.
5. Deliver a responsive web dashboard with interactive charts and automated textual insights.
6. Ensure the system degrades gracefully when a database server is not available (simulation mode).

---

## 4. Literature Survey

| Reference | Contribution |
|-----------|-------------|
| Cattell (2011) — "Scalable SQL and NoSQL Data Stores" | Taxonomy of NoSQL systems and performance trade-offs. |
| Abramova & Bernardino (2013) — "NoSQL Databases: MongoDB, Cassandra, HBase" | Comparative CRUD performance at 10 K–1 M records using YCSB. |
| Rabl et al. (2012) — "Solving Big Data Challenges for Enterprise Application Performance Management" | Identifies throughput and latency as primary selection criteria. |
| Redis Labs (2022) — "Redis Benchmark Guide" | Pipeline optimisation and in-memory vs. on-disk trade-offs. |
| MongoDB, Inc. (2023) — "MongoDB Performance Best Practices" | Index selection and aggregation pipeline tuning. |
| Apache Software Foundation (2023) — "Cassandra Architecture" | Ring topology, consistency levels, and compaction strategies. |

---

## 5. Existing Systems

**Yahoo! Cloud Serving Benchmark (YCSB)**
- Strengths: Industry-standard, extensible, supports dozens of databases.
- Weaknesses: Java-based, complex configuration, no built-in visual dashboard, no CPU/memory capture.

**HammerDB**
- Strengths: GUI-driven, TPC-C/TPC-H workloads.
- Weaknesses: Primarily targets relational databases; limited NoSQL support.

**Apache JMeter**
- Strengths: Distributed load testing, rich plugins.
- Weaknesses: Not NoSQL-specific; no analytical comparison layer.

---

## 6. Proposed System

A Python-native, Flask-powered benchmark suite with:

- **Automated dataset generation** using the Faker library.
- **Uniform connector API** abstracting MongoDB, Cassandra, and Redis.
- **Background benchmark execution** with real-time SSE progress streaming.
- **Simulation fallback** generating statistically plausible results when databases are offline.
- **Interactive dashboard** with Chart.js bar/line charts and auto-generated textual insights.
- **Zero-configuration** — runs with `python app.py` after `pip install -r requirements.txt`.

---

## 7. Methodology

```
Generate Datasets → Connect Databases → Execute CRUD Ops →
Capture Metrics   → Save CSV          → Analyse Results  →
Render Dashboard
```

### 7.1 Dataset Generation
The `Faker` library generates realistic `user_id`, `name`, `email`, `city`, `age`, and `timestamp` fields. Four dataset sizes are produced: 1 K, 10 K, 50 K, 100 K. NumPy seeds (`np.random.seed(42)`) ensure reproducibility.

### 7.2 Benchmarking Protocol
For each (database, dataset-size) pair:
1. **Insert** — bulk-load all records; time from first write to last acknowledgement.
2. **Read** — full collection scan; time to materialise all documents in memory.
3. **Update** — increment `age` for every record; single-pass scan.
4. **Delete** — remove the first 10 % of records by `user_id`.

CPU and memory are sampled at 100 ms intervals by a background thread using `psutil`; averages are reported.

### 7.3 Metrics
| Metric | Formula |
|--------|---------|
| Elapsed (s) | `time.perf_counter()` delta |
| Throughput (rps) | `records_affected / elapsed_sec` |
| CPU % | mean of `psutil.Process.cpu_percent()` samples |
| Memory MB | mean of `psutil.Process.memory_info().rss / 1024²` |

---

## 8. System Design

### 8.1 Folder Structure
```
performance_evaluation_nosql/
├── app.py                     # Flask entry point
├── benchmark_engine.py        # Benchmark orchestrator
├── dataset_generator.py       # Synthetic data generation
├── performance_analyzer.py    # Analytics & rankings
├── requirements.txt
├── database/
│   ├── __init__.py
│   ├── mongodb_connector.py
│   ├── cassandra_connector.py
│   └── redis_connector.py
├── templates/
│   ├── index.html
│   ├── benchmark.html
│   ├── results.html
│   └── analytics.html
├── static/
│   ├── css/style.css
│   └── js/charts.js
├── datasets/                  # Auto-generated CSVs
├── results/                   # results.csv saved here
└── documentation/
```

### 8.2 Data Flow
```
User (browser)
    │  HTTP GET /benchmark
    ▼
Flask app.py
    │  POST /benchmark/run
    ▼
benchmark_engine.run_benchmarks()
    ├── dataset_generator.load_dataset()
    │       └── datasets/*.csv
    ├── MongoDBConnector.insert/read/update/delete()
    ├── CassandraConnector.insert/read/update/delete()
    ├── RedisConnector.insert/read/update/delete()
    └── results/results.csv
    │
performance_analyzer.get_full_analysis()
    └── Flask renders analytics.html + charts.js
```

---

## 9. Architecture Diagram

```
┌──────────────────────────────────────────────────────────┐
│                     Web Browser (User)                   │
│           / · /benchmark · /results · /analytics         │
└────────────────────────┬─────────────────────────────────┘
                         │ HTTP
┌────────────────────────▼─────────────────────────────────┐
│                  Flask Application (app.py)              │
│  Routes: index · benchmark · results · analytics · API   │
└──────┬──────────────────┬────────────────────────────────┘
       │                  │
┌──────▼──────┐   ┌───────▼─────────────────────────────────┐
│  Dataset    │   │          Benchmark Engine               │
│  Generator  │   │  (benchmark_engine.py)                  │
│             │   │  ResourceSampler (psutil thread)        │
└──────┬──────┘   └──────┬──────────┬────────────┬──────────┘
       │ CSV              │          │            │
       │          ┌───────▼──┐ ┌────▼──────┐ ┌──▼──────────┐
       │          │ MongoDB  │ │Cassandra  │ │   Redis     │
       │          │Connector │ │Connector  │ │  Connector  │
       │          └──────────┘ └───────────┘ └─────────────┘
       │                  │
       │          ┌───────▼────────────┐
       └─────────►│   results.csv      │
                  └───────┬────────────┘
                          │
                  ┌───────▼────────────────┐
                  │  Performance Analyzer  │
                  │  (performance_         │
                  │   analyzer.py)         │
                  └───────┬────────────────┘
                          │ JSON
                  ┌───────▼────────────┐
                  │  analytics.html    │
                  │  + Chart.js        │
                  └────────────────────┘
```

---

## 10. Algorithms

### Algorithm 1 — Benchmark Orchestration
```
INPUT:  size_labels[], databases[]
OUTPUT: results.csv

FOR each size_label IN size_labels:
    df ← load_dataset(size_label)
    FOR each db IN databases:
        IF db.connect() FAILS:
            APPEND simulate(db, size_label) TO rows
            CONTINUE
        FOR each op IN [insert, read, update, delete]:
            sampler.start()
            elapsed ← db.op(df)
            sampler.stop()
            throughput ← records / elapsed
            APPEND {db, size, op, elapsed, throughput,
                    sampler.avg_cpu, sampler.avg_mem} TO rows
SAVE rows → results.csv
```

### Algorithm 2 — Ranking
```
INPUT:  results.csv
OUTPUT: ranked_lists{}

avg ← GROUP_BY(database).MEAN(numeric_cols)
ranked_lists["fastest"]    ← SORT_BY(avg.elapsed_sec,    ASC)
ranked_lists["throughput"] ← SORT_BY(avg.throughput_rps, DESC)
ranked_lists["cpu"]        ← SORT_BY(avg.cpu_pct,        ASC)
ranked_lists["mem"]        ← SORT_BY(avg.mem_mb,         ASC)

ins_1k   ← FILTER(operation=insert, dataset=1k)
ins_100k ← FILTER(operation=insert, dataset=100k)
scale_ratio ← ins_100k.elapsed / ins_1k.elapsed
ranked_lists["scalable"] ← SORT_BY(scale_ratio, ASC)
```

---

## 11. Flowcharts

### Main Application Flow
```
START
  │
  ▼
User visits /benchmark
  │
  ▼
Select dataset sizes → POST /benchmark/run
  │
  ▼
Thread: run_benchmarks()
  │
  ├─► Generate missing datasets
  │
  ├─► For each DB: connect()
  │       ├─ Success → run CRUD ops
  │       └─ Fail    → simulate results
  │
  ├─► Save results.csv
  │
  └─► Signal done (pct=100)
  │
  ▼
Browser polls /benchmark/status → shows progress
  │
  ▼
Done → redirect to /results or /analytics
  │
  ▼
STOP
```

---

## 12. Implementation Notes

### MongoDB Connector
Uses `pymongo` with `insert_many(ordered=False)` for maximum insert speed. A unique index on `user_id` prevents duplicates. Read uses a cursor scan; delete uses `$in` for batch removal.

### Cassandra Connector
Uses `cassandra-driver` with `BatchStatement` (max 200 ops per batch — Cassandra's recommended limit). PreparedStatements are used for all parameterised CQL to benefit from server-side query caching.

### Redis Connector
Uses `redis-py` pipelined commands (PIPELINE_BATCH=500) to minimise round-trip overhead. Each user is stored as a Hash (`user:{user_id}`). Flush uses `DEL *keys` in batches.

### Simulation Fallback
When a database server is not reachable (e.g., Cassandra not installed), `benchmark_engine._simulate()` produces statistically plausible numbers derived from documented baseline performance characteristics, scaled by dataset size with a small random jitter. This ensures the dashboard always has data to display in academic demonstration environments.

---

## 13. Results and Analysis

(Populated automatically after running the benchmark — see /analytics)

**Typical findings (order of magnitude):**

| Operation | Fastest DB | Reason |
|-----------|-----------|--------|
| Insert    | Redis      | In-memory pipeline writes |
| Read      | Redis      | O(1) hash lookups, pipeline batch reads |
| Update    | Redis      | Direct hash field mutation |
| Delete    | MongoDB    | Indexed `$in` bulk delete |

**Scalability:** Redis maintains near-linear scaling due to O(1) operations. MongoDB's B-tree indices give sub-linear read scaling. Cassandra's LSM-tree is optimised for write-heavy workloads at very high record counts.

---

## 14. Advantages

- Language-agnostic dataset format (CSV) enables reuse with other tools.
- Simulation mode allows demoing the full UI without installed databases.
- Modular connector design makes adding new databases (e.g., DynamoDB) trivial.
- Real-time progress polling keeps the UI responsive during long benchmarks.
- Automated textual insights lower the barrier for non-expert interpretation.

---

## 15. Limitations

- Single-node benchmarks only; distributed deployment is not simulated.
- CPU/memory measurements reflect the entire Python process, not only the database driver.
- Redis results favour in-memory workloads; persistence (AOF/RDB) is disabled.
- Cassandra performance is sensitive to JVM heap and compaction settings not tuned here.
- Network latency between the application and database server is not isolated.

---

## 16. Future Scope

1. Add HBase, DynamoDB, and CouchDB connectors.
2. Support distributed benchmark runs (multiple client machines).
3. Export results as PDF reports.
4. Add query complexity benchmarks (aggregations, joins, secondary index lookups).
5. Integrate with Prometheus + Grafana for real-time system metrics.
6. Docker Compose configuration to spin up all three databases automatically.
7. REST API for programmatic benchmark triggering from CI/CD pipelines.

---

## 17. Conclusion

This project demonstrates that the "best" NoSQL database is inherently workload-dependent. Redis dominates latency-sensitive read/write workloads due to its in-memory architecture. MongoDB offers the best balance of query flexibility and write throughput for medium-scale document workloads. Cassandra's write-optimised LSM-tree makes it the preferred choice for large-scale append-heavy workloads.

The implemented benchmark suite provides a reproducible, extensible, and visually rich platform for making evidence-based database selection decisions — a practical tool of lasting value beyond the academic submission context.

---

## 18. References

1. Cattell, R. (2011). Scalable SQL and NoSQL data stores. *ACM SIGMOD Record*, 39(4), 12–27.
2. Abramova, V., & Bernardino, J. (2013). NoSQL databases: MongoDB, Cassandra, HBase. In *ICEIS 2013*.
3. Rabl, T., et al. (2012). Solving Big Data Challenges for Enterprise Application Performance Management. *PVLDB*, 5(12).
4. Apache Cassandra Documentation. (2023). https://cassandra.apache.org/doc/latest/
5. MongoDB Manual. (2023). https://www.mongodb.com/docs/manual/
6. Redis Documentation. (2023). https://redis.io/docs/
7. Cooper, B. F., et al. (2010). Benchmarking Cloud Serving Systems with YCSB. *SoCC '10*.
8. psutil Documentation. (2023). https://psutil.readthedocs.io/
9. Flask Documentation. (2023). https://flask.palletsprojects.com/
10. Chart.js Documentation. (2023). https://www.chartjs.org/docs/
