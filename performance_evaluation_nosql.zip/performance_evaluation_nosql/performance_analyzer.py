"""
performance_analyzer.py
Reads results/results.csv and produces analytical summaries,
rankings, and comparisons consumed by the Flask dashboard.
"""

import os
import json
import pandas as pd
import numpy as np

RESULTS_CSV = os.path.join(os.path.dirname(__file__), "results", "results.csv")
DATABASES   = ["MongoDB", "Cassandra", "Redis"]
OPERATIONS  = ["insert", "read", "update", "delete"]
SIZES       = ["1k", "10k", "50k", "100k"]


def _load() -> pd.DataFrame | None:
    if not os.path.exists(RESULTS_CSV):
        return None
    df = pd.read_csv(RESULTS_CSV)
    df["elapsed_sec"]    = pd.to_numeric(df["elapsed_sec"],    errors="coerce")
    df["throughput_rps"] = pd.to_numeric(df["throughput_rps"], errors="coerce")
    df["cpu_pct"]        = pd.to_numeric(df["cpu_pct"],        errors="coerce")
    df["mem_mb"]         = pd.to_numeric(df["mem_mb"],         errors="coerce")
    return df


# ── Public API ────────────────────────────────────────────────────────

def get_summary_table() -> list[dict]:
    """
    Returns a list of dicts, one per (database, operation, dataset),
    suitable for rendering an HTML table.
    """
    df = _load()
    if df is None:
        return []
    cols = ["database", "dataset", "operation", "records",
            "elapsed_sec", "throughput_rps", "cpu_pct", "mem_mb"]
    return df[cols].round(4).to_dict("records")


def get_chart_data() -> dict:
    """
    Returns a dict of chart-ready data for Chart.js:
      - by_operation[op]  → {labels:[db…], elapsed:[…], throughput:[…]}
      - scalability[db]   → {labels:[size…], elapsed:[…]}
      - resources         → {labels:[db…], cpu:[…], mem:[…]}
    """
    df = _load()
    if df is None:
        return {}

    # Average across all dataset sizes
    avg = df.groupby(["database", "operation"], as_index=False).mean(numeric_only=True)

    by_op = {}
    for op in OPERATIONS:
        sub = avg[avg["operation"] == op].set_index("database").reindex(DATABASES)
        by_op[op] = {
            "labels":     DATABASES,
            "elapsed":    sub["elapsed_sec"].fillna(0).round(4).tolist(),
            "throughput": sub["throughput_rps"].fillna(0).round(2).tolist(),
        }

    # Scalability: insert elapsed vs dataset size, per db
    ins = df[df["operation"] == "insert"]
    scalability = {}
    for db in DATABASES:
        sub = ins[ins["database"] == db].set_index("dataset").reindex(SIZES)
        scalability[db] = {
            "labels":  SIZES,
            "elapsed": sub["elapsed_sec"].fillna(0).round(4).tolist(),
        }

    # Resource usage averaged across all ops and sizes
    res = df.groupby("database", as_index=False).mean(numeric_only=True).set_index("database").reindex(DATABASES)
    resources = {
        "labels": DATABASES,
        "cpu":    res["cpu_pct"].fillna(0).round(2).tolist(),
        "mem":    res["mem_mb"].fillna(0).round(2).tolist(),
    }

    return {"by_operation": by_op, "scalability": scalability, "resources": resources}


def get_rankings() -> dict:
    """
    Returns ranked lists identifying:
      fastest_db, best_throughput, lowest_cpu, lowest_mem, most_scalable
    """
    df = _load()
    if df is None:
        return {}

    avg = df.groupby("database", as_index=False).mean(numeric_only=True)

    def rank(col: str, ascending: bool = True) -> list[str]:
        return avg.sort_values(col, ascending=ascending)["database"].tolist()

    # Scalability = how much insert time grows from 1k → 100k (lower ratio = better)
    ins  = df[df["operation"] == "insert"]
    base = ins[ins["dataset"] == "1k"].set_index("database")["elapsed_sec"]
    top  = ins[ins["dataset"] == "100k"].set_index("database")["elapsed_sec"]
    scale_ratio = (top / base.replace(0, np.nan)).reindex(DATABASES)
    most_scalable = scale_ratio.sort_values().index.tolist()

    return {
        "fastest_db":      rank("elapsed_sec",    ascending=True),
        "best_throughput": rank("throughput_rps",  ascending=False),
        "lowest_cpu":      rank("cpu_pct",         ascending=True),
        "lowest_mem":      rank("mem_mb",          ascending=True),
        "most_scalable":   most_scalable,
    }


def get_insights() -> list[str]:
    """Returns a list of plain-English analytical insight strings."""
    df = _load()
    if df is None:
        return ["No benchmark data available yet. Run a benchmark first."]

    insights = []
    rankings = get_rankings()

    fastest = rankings.get("fastest_db", [None])[0]
    if fastest:
        avg_e = df[df["database"] == fastest]["elapsed_sec"].mean()
        insights.append(
            f"{fastest} is the overall fastest database with an average operation "
            f"time of {avg_e:.3f}s across all workloads."
        )

    best_tp = rankings.get("best_throughput", [None])[0]
    if best_tp:
        avg_tp = df[df["database"] == best_tp]["throughput_rps"].mean()
        insights.append(
            f"{best_tp} achieves the highest throughput, processing an average of "
            f"{avg_tp:,.0f} records/second."
        )

    low_mem = rankings.get("lowest_mem", [None])[0]
    if low_mem:
        avg_m = df[df["database"] == low_mem]["mem_mb"].mean()
        insights.append(
            f"{low_mem} is the most memory-efficient, averaging {avg_m:.1f} MB "
            "across all operations."
        )

    scalable = rankings.get("most_scalable", [None])[0]
    if scalable:
        insights.append(
            f"{scalable} scales most gracefully — its execution time grows the "
            "least as dataset size increases from 1 K to 100 K records."
        )

    # Operation-specific
    for op in OPERATIONS:
        sub = df[df["operation"] == op]
        best = sub.loc[sub["elapsed_sec"].idxmin(), "database"] if not sub.empty else None
        if best:
            t = sub[sub["database"] == best]["elapsed_sec"].mean()
            insights.append(f"For {op.upper()} operations, {best} leads with {t:.3f}s avg.")

    return insights


def get_full_analysis() -> dict:
    """Aggregate all analysis into one dict for the analytics page."""
    return {
        "summary_table": get_summary_table(),
        "chart_data":    get_chart_data(),
        "rankings":      get_rankings(),
        "insights":      get_insights(),
    }
