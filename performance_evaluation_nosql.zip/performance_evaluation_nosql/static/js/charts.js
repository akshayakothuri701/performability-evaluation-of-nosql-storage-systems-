/**
 * charts.js
 * Initialises all Chart.js charts on the Analytics page.
 * Called from analytics.html after Chart.js is loaded.
 *
 * Expected global: CHART_DATA (injected by Flask as JSON)
 */

const DB_COLORS = {
  MongoDB:   { bg: "rgba(0,237,100,0.25)",    border: "rgba(0,237,100,0.9)"    },
  Cassandra: { bg: "rgba(18,135,177,0.25)",   border: "rgba(18,135,177,0.9)"   },
  Redis:     { bg: "rgba(255,68,56,0.25)",    border: "rgba(255,68,56,0.9)"    },
};

const CHART_DEFAULTS = {
  responsive: true,
  maintainAspectRatio: true,
  plugins: {
    legend: {
      labels: { color: "#94a3b8", font: { family: "Inter", size: 12 } }
    },
    tooltip: {
      backgroundColor: "#162032",
      titleColor: "#e2e8f0",
      bodyColor: "#94a3b8",
      borderColor: "rgba(255,255,255,0.1)",
      borderWidth: 1,
    }
  },
  scales: {
    x: {
      ticks: { color: "#94a3b8", font: { size: 11 } },
      grid:  { color: "rgba(255,255,255,0.05)" },
    },
    y: {
      ticks: { color: "#94a3b8", font: { size: 11 } },
      grid:  { color: "rgba(255,255,255,0.05)" },
      beginAtZero: true,
    }
  }
};

function makeBarDataset(label, data, dbName) {
  const c = DB_COLORS[dbName] || { bg: "rgba(99,102,241,0.25)", border: "rgba(99,102,241,0.9)" };
  return {
    label,
    data,
    backgroundColor: c.bg,
    borderColor:     c.border,
    borderWidth: 2,
    borderRadius: 6,
  };
}

function makeLineDataset(label, data, dbName) {
  const c = DB_COLORS[dbName] || { bg: "rgba(99,102,241,0.25)", border: "rgba(99,102,241,0.9)" };
  return {
    label,
    data,
    borderColor:     c.border,
    backgroundColor: c.bg,
    pointBackgroundColor: c.border,
    pointRadius: 5,
    fill: false,
    tension: 0.3,
  };
}

// ── Insert elapsed ───────────────────────────────────────────────────
function buildInsertElapsed(data) {
  const op = data.by_operation.insert;
  new Chart(document.getElementById("chartInsertElapsed"), {
    type: "bar",
    data: {
      labels: op.labels,
      datasets: [makeBarDataset("Elapsed (s)", op.elapsed, null)].map((ds, i) => ({
        ...ds,
        backgroundColor: op.labels.map(l => (DB_COLORS[l] || {}).bg    || "rgba(99,102,241,0.25)"),
        borderColor:     op.labels.map(l => (DB_COLORS[l] || {}).border || "rgba(99,102,241,0.9)"),
      }))
    },
    options: {
      ...CHART_DEFAULTS,
      plugins: { ...CHART_DEFAULTS.plugins, legend: { display: false } },
    }
  });
}

// ── Insert throughput ─────────────────────────────────────────────────
function buildInsertThroughput(data) {
  const op = data.by_operation.insert;
  new Chart(document.getElementById("chartInsertTp"), {
    type: "bar",
    data: {
      labels: op.labels,
      datasets: [{
        label: "Throughput (rps)",
        data: op.throughput,
        backgroundColor: op.labels.map(l => (DB_COLORS[l] || {}).bg    || "rgba(99,102,241,0.25)"),
        borderColor:     op.labels.map(l => (DB_COLORS[l] || {}).border || "rgba(99,102,241,0.9)"),
        borderWidth: 2,
        borderRadius: 6,
      }]
    },
    options: {
      ...CHART_DEFAULTS,
      plugins: { ...CHART_DEFAULTS.plugins, legend: { display: false } },
    }
  });
}

// ── Read elapsed ──────────────────────────────────────────────────────
function buildReadElapsed(data) {
  const op = data.by_operation.read;
  new Chart(document.getElementById("chartReadElapsed"), {
    type: "bar",
    data: {
      labels: op.labels,
      datasets: [{
        label: "Read Elapsed (s)",
        data: op.elapsed,
        backgroundColor: op.labels.map(l => (DB_COLORS[l] || {}).bg    || "rgba(99,102,241,0.25)"),
        borderColor:     op.labels.map(l => (DB_COLORS[l] || {}).border || "rgba(99,102,241,0.9)"),
        borderWidth: 2,
        borderRadius: 6,
      }]
    },
    options: {
      ...CHART_DEFAULTS,
      plugins: { ...CHART_DEFAULTS.plugins, legend: { display: false } },
    }
  });
}

// ── Update & Delete ───────────────────────────────────────────────────
function buildUpdDel(data) {
  const upd = data.by_operation.update;
  const del = data.by_operation.delete;
  new Chart(document.getElementById("chartUpdDel"), {
    type: "bar",
    data: {
      labels: upd.labels,
      datasets: [
        {
          label: "Update (s)",
          data: upd.elapsed,
          backgroundColor: "rgba(251,191,36,0.25)",
          borderColor:     "rgba(251,191,36,0.9)",
          borderWidth: 2, borderRadius: 6,
        },
        {
          label: "Delete (s)",
          data: del.elapsed,
          backgroundColor: "rgba(248,113,113,0.25)",
          borderColor:     "rgba(248,113,113,0.9)",
          borderWidth: 2, borderRadius: 6,
        }
      ]
    },
    options: CHART_DEFAULTS,
  });
}

// ── Scalability line chart ────────────────────────────────────────────
function buildScalability(data) {
  const sc = data.scalability;
  const datasets = Object.keys(sc).map(db => makeLineDataset(db, sc[db].elapsed, db));
  const labels = sc[Object.keys(sc)[0]].labels;
  new Chart(document.getElementById("chartScale"), {
    type: "line",
    data: { labels, datasets },
    options: {
      ...CHART_DEFAULTS,
      scales: {
        ...CHART_DEFAULTS.scales,
        x: { ...CHART_DEFAULTS.scales.x, title: { display: true, text: "Dataset Size", color: "#64748b" } },
        y: { ...CHART_DEFAULTS.scales.y, title: { display: true, text: "Insert Time (s)", color: "#64748b" } },
      }
    }
  });
}

// ── Resource usage ────────────────────────────────────────────────────
function buildResources(data) {
  const res = data.resources;
  new Chart(document.getElementById("chartResource"), {
    type: "bar",
    data: {
      labels: res.labels,
      datasets: [
        {
          label: "Avg CPU %",
          data: res.cpu,
          backgroundColor: "rgba(99,102,241,0.3)",
          borderColor:     "rgba(99,102,241,0.9)",
          borderWidth: 2, borderRadius: 6,
          yAxisID: "yCpu",
        },
        {
          label: "Avg Mem MB",
          data: res.mem,
          backgroundColor: "rgba(167,139,250,0.3)",
          borderColor:     "rgba(167,139,250,0.9)",
          borderWidth: 2, borderRadius: 6,
          yAxisID: "yMem",
        }
      ]
    },
    options: {
      ...CHART_DEFAULTS,
      scales: {
        x:    CHART_DEFAULTS.scales.x,
        yCpu: { ...CHART_DEFAULTS.scales.y, position: "left",  title: { display: true, text: "CPU %",    color: "#94a3b8" } },
        yMem: { ...CHART_DEFAULTS.scales.y, position: "right", title: { display: true, text: "Memory MB", color: "#94a3b8" }, grid: { drawOnChartArea: false } },
      }
    }
  });
}

// ── Public entry point ────────────────────────────────────────────────
function initCharts(data) {
  if (!data || !data.by_operation) return;
  buildInsertElapsed(data);
  buildInsertThroughput(data);
  buildReadElapsed(data);
  buildUpdDel(data);
  buildScalability(data);
  buildResources(data);
}
